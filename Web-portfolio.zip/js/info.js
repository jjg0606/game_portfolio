var info =
[{
    "name": "BlindAssassin",
    "desc": "<li>대학생 때 과제로 만든 대학생 때 과제로 만든 게임입니다.</li><li>c++언어를 기본으로, fmod, opengl  등을 이용해서 만들었습니다.</li><li>3인 팀플로 만들었고</li><li>저는 opengl을 이용해서 화면구성을 하고</li><li>충돌처리와 적 ai인공지능 등을 맡았습니다.</li>",
    "title_img": "./img/ba_title.bmp",
    "info": "bainfo"
},
{
    "name": "테트리스",
    "desc": "<li>유니티로 혼자 만든 첫 게임입니다.</li><li> 테트리스는 게임엔진의 기능 보다는 스스로 만든 로직으로 구현할 수 있다는 점에서 연습작품으로 좋다고 느껴서 시도해봤습니다.</li><li> 제작기간은 2일입니다.</li>",
    "title_img": "./img/ta_title.bmp",
    "info": "tainfo"
},
{
    "name": "2D 플랫포머",
    "desc": "<li>테트리스 이후에 슈퍼마리오처럼 간단하지만, 재밌게 할 수 있는 게임을 구상하다가 만들게 된 2d 플랫포머 게임입니다. </li><li>독자적인 로직으로만 돌아가는 테트리스 말고, 유니티의 충돌이나 물리엔진을 이용해보고 싶어서 간단하게 만들어봤습니다.</li>",
    "title_img": "./img/pl_title.bmp",
    "info": "plinfo"
},
{
    "name":"Village_and_Conquer",
    "desc":"<li>대학 졸업과제때 3인 팀프로젝트로 만든 유니티 게임입니다.</li><li>문명과 시티빌더 게임을 합치려는 시도로 만들어졌으며</li><li>건물을 짓고, 자원을 수집하고, 마왕을 죽이는 것이 목표입니다.</li><li>제가 담당한 부분은 지형생성, 미니맵, 기획이었습니다.</li>",
    "title_img":"./img/vq_title.png",
    "info":"vqinfo"
}

];